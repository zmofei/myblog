define(function(require, exports, module) {
    //
    'use strict';
    //
    var blocks = document.querySelectorAll('.showarea .block');
    var showin = document.querySelectorAll('.showarea_in');
    for (var i = 0, len = showin.length; i < len; i++) {
        showin[i].style.width = showin[i].querySelectorAll('.block').length * 352 + 'px';
    }
    showin[0].style.display = 'block';

    var colors = document.querySelectorAll('.showcolors_block');
    for (var i = 0; i < colors.length; i++) {
        (function(i) {
            colors[i].onclick = function() {
                for (var j = 0, lenj = showin.length; j < lenj; j++) {
                    showin[j].style.display = 'none';
                }
                showin[i].style.display = 'block';
                document.querySelector('.colorname').value = i
            };
        })(i);
    }

    var size = document.querySelectorAll('.showsize span');
    for (var i = 0; i < size.length; i++) {
        (function(i) {
            size[i].onclick = function() {
                document.querySelector('.sizenumber').value = this.innerHTML;
            }
        })(i)
    };
    
    var plus=document.querySelector('.numberplus');
    var min=document.querySelector('.numbermin');
    plus.onclick=function(){
        document.querySelector('.numberinput').value = parseInt(document.querySelector('.numberinput').value || 0) - 1
    }
    min.onclick=function(){
        document.querySelector('.numberinput').value = parseInt(document.querySelector('.numberinput').value || 0) + 1
    }
    
    
    var way=document.querySelectorAll('.showway a');
    for(var i=0;i<way.length;i++){
        (function(i){
            way[i].onclick=function(){
                document.querySelector('.buyinput').value=i;
                for(var j=0;j<way.length;j++){
                    way[j].setAttribute('class','');
                }
                this.setAttribute('class','active');
                return false;
            }
        })(i);
    }
}); 